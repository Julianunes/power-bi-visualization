class DatasetLoader:
    def __init__(self, dataset):
        self.dataset = dataset
